from django.shortcuts import render
from Home import models
# Create your views here.
def Access(request):
    status = False
    valid = 0
    if request.method == "POST":
       name = request.POST.get('username')
       passwrd = request.POST.get('password')
       data = models.Registration_Form.objects.all()


       for i in data:
           valid = 0
           if name == i.username:
               valid += 1
               user = i.name
               phone = i.phone
               email = i.email

           if passwrd == i.password:
               valid += 1
           if valid == 2:
               break
    if valid == 2:
        user_data = {'name':user,'email':email,'phone':phone}
        return render(request, "Dashboard.html",{'user_data': user_data})
    else:
        return render(request, "LoginPage.html",{'context': status})