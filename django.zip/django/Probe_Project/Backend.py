from django.core.mail import send_mail 
def Send_Email(email):
    send_mail(
        'Welcome Message From CARE Smart Farms',
        'Here is the message.',
        'engr.smab@gmail.com',
        [email],
        fail_silently=False,
    )
def FetchData(data,email,username):
    mail = False
    user = False
    for i in data:
        if email == i.email:
            mail = True
        if username == i.username:
            user = True
    return mail,user
