from django.db import models

# Create your models here.
class Registration_Form(models.Model):
    name = models.CharField(max_length=20)
    email = models.EmailField()
    phone = models.CharField(max_length=11)
    username = models.CharField(max_length=20)
    password = models.CharField(max_length=20)
