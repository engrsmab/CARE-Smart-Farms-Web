from django.shortcuts import render
from Home import models
from Probe_Project import Backend
# Create your views here.
def Home_page(request,*args,**kwargs):
    return render(request,"Home.html",{})
def Registration_page(request):
    return render(request,"Register.html",{})
def Register(request):
    status = False
    value_error = ["HTML Form Error. Please Refresh this page"]
    if request.method == "POST":
       name = request.POST.get('fname')
       email = request.POST.get('mail')
       phone = request.POST.get('phone')
       username = request.POST.get('username')
       password = request.POST.get('password')
       re_pass = request.POST.get('re_pass')
       error = 0
       value_error = []

       if len(phone) != 11:
           error = 1
           value_error.append("Invalid Phone Format. Please Provide 11 digit Pakistan Phone Number \n i.e "
                              "03012345678")

       if len(password) < 7:
           error = 1
           value_error.append("Invalid Password. Please Enter at least 8 digit password")
       if password != re_pass:
           error = 1
           value_error.append("Password Confirmation error. Please re enter password")
       if error == 0:

           data = models.Registration_Form.objects.all()
           mail,user = Backend.FetchData(data,email,username)
           if mail == True:
               value_error.append("This Email is already registered.")
               error = 1
           if user == True:
               value_error.append("This Username is not available. Please try another Username")
               error = 1
           if error == 0:
               submit = models.Registration_Form(name=name, email=email, phone=phone, username=username,
                                                 password=password)
               submit.save()
               status = True
    data = {'status': status, 'errors': value_error}

    return render(request,"Register.html", {'context': data})
def Login(request):
    return render(request, "LoginPage.html", {})

def Reset_Panel(request):
    status = True
    return render(request, "LoginPage.html", {'Forgot_Panel': status})
def Varify_email(request):
    valid = False
    if request.method == "POST":
       email = request.POST.get('email')
       data = models.Registration_Form.objects.all()

       for i in data:
           if email == i.email:
               valid = True
       if valid == 1:
          pass
          # Backend.Send_Email(email)


    return render(request, "LoginPage.html", {'Varify': valid})
def Varification(request):
    return render(request,"LoginPage.html",{'Email_Sent': True})
